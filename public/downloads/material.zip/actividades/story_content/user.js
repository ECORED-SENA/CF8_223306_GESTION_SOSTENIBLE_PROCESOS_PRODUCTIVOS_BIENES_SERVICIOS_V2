function ExecuteScript(strId)
{
  switch (strId)
  {
      case "67LgZq6fp7F":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

